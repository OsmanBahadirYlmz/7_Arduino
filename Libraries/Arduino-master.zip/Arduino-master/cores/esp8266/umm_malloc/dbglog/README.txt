Downloaded from: https://github.com/rhempel/c-helper-macros/tree/develop
Applied uncrustify to be consistent with the rest of the umm_malloc files.
