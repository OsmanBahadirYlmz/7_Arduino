#include "./display.h"
void calculateGraphics();