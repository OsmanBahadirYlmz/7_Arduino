#include <TimeLib.h>
#include <ESP8266WiFi.h>
#include <WiFiUdp.h>

String digitalClockValue();
String printDigits(int digits);

void startTime();